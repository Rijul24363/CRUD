package com.cf.manipal.arch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cf.manipal.arch.entity.Employee;
import com.cf.manipal.arch.exception.BusinessException;
import com.cf.manipal.arch.repository.EmployeeRepository;

@Service
public class EmployeeService implements EmployeeServiceInterface{
	
	@Autowired
	private EmployeeRepository emprepo;

	
	@Override
	public Employee addEmployee(Employee employee) {
		try {
			if(employee.getName().isEmpty() || employee.getName().length()==0) {
				throw new BusinessException("601","Please send proper name, Its blank");
			}
			Employee savedEmployee = emprepo.save(employee);
			return savedEmployee;
			} catch(IllegalArgumentException e) {
				throw new BusinessException("602","given emloyee is null" + e.getMessage());
				
			}
		 catch(Exception e) {
				throw new BusinessException("603","Something wnt wrong in the service layer" + e.getMessage());
				
			}
		
	}


	@Override
	public List<Employee> getEmployee() {
		try {
		List<Employee> emplist = emprepo.findAll();
		if(emplist.isEmpty()) 
			throw new BusinessException("604","List is Empty, There is no data in database");
		return emprepo.findAll();	
		} catch (Exception e) {
			throw new BusinessException("605" , "Something went wrong in service layer"+ e.getMessage());
		}
		
	}


	@Override
	public void deleteEmpById(Long empidLong) {
		try {
		emprepo.deleteById(empidLong);
	} catch(IllegalArgumentException e) {
		throw new BusinessException("606", "Given id is null" + e.getMessage());
	}

}}


