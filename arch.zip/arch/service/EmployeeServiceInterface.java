package com.cf.manipal.arch.service;


import java.util.List;

import com.cf.manipal.arch.entity.Employee;

public interface EmployeeServiceInterface {

	
	public Employee addEmployee(Employee employee);

	public List<Employee> getEmployee();

	public void deleteEmpById(Long empidLong);

}
